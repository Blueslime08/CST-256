
<html>

<h2>Inputs put in</h2>
<table>
	<tr>
		<td>The inputs were:</td>
		<td>{{ $inputs->getInput1() }}</td>
		<td>{{ $inputs->getInput2() }}</td>
		<td>{{ $inputs->getInput3() }}</td>
		<td>{{ $inputs->getInput4() }}</td>
	</tr>
</table>

</html>