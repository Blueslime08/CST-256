<form action="doInput" method="POST">
	<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
	<h2>Inputs</h2>
		@if(isset($error))
    		<div style="color: red">
        		Error: {{ $error }} <br>
        		<br>
        	</div>
    	@endif	
    	
	<table>
		<tr>
			<td>Input 1:</td>
			<td><input type="text" name="1" /></td>
		</tr>
		
		<tr>
			<td>Input 2:</td>
			<td><input type="text" name="2" /></td>
		</tr>
		<tr>
			<td>Input 3:</td>
			<td><input type="text" name="3" /></td>
		</tr>

		<tr>
			<td>Input 4:</td>
			<td><input type="text" name="4" /></td>
		</tr>
		<tr>
			<td colspan="2" align="center">			<br>
			<input type="submit" value="Submit" />
			</td>
		</tr>
	</table>	
</form>