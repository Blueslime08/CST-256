<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;

class InputController
{
    function getInputs(Request $request)
    {
        //declare variables passed in from form
        $input1 = $request->input('1');
        $input2 = $request->input('2');
        $input3 = $request->input('3');
        $input4 = $request->input('4');
        
        //returns the view with inputs
        return View('inputs');
    }
    
}