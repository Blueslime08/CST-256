<?php
namespace App\Services\Business;

use App\Model\inputs;

class SecurityService
{
    
    //validates register form request
    public function input($inputs) {
        
        //filters passed in variables
        $i1 = $this->filter($inputs->getInput1());
        $i2 = $this->filter($inputs->getInput2());
        $i3 = $this->filter($inputs->getInput3());
        $i4 = $this->filter($inputs->getInput4());
        
        //binds them
        $inputs->setInput1($i1);
        $inputs->setInput2($i2);
        $inputs->setInput3($i3);
        $inputs->setInput4($i4);
    
        }
    
    //checks for same string
    function match($string)
    {
        //if matches return true
        if(preg_match('CST-256', $string) == 7)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}


