<?php
namespace App\Services\Data;


use Carbon\Exceptions\Exception;
use App\Services\Data\Utility\DBConnect;
use App\Models\CustomerModel;

class CustomerDAO
{
    //Define connection string
    private $connObject;
    private $dbname = "activity3";
    private $dbquery;
    private $connection;
    private $dbObj;
    
    //constructor that creates conn with database
    public function __construct($dbObj)
    {
        $this->dbObj = $dbObj;
    }
    //method to add new order
    public function addCustomer(CustomerModel $customerdata)
    {
        try 
        {
            
            $this->dbquery ="INSERT INTO customer
                             (FirstName, LastName)
                             VALUES
                             ('{$customerdata->getFirstName()}', '{$customerdata->getLastName()}')";
            
            //$result = mysqli_query($this->conn, $this->dbquery);
            
            if( $this->dbObj->query($this->dbquery))
            {
                //$this->connObject->closeDbConnect();
                return true;
            }
            else 
            {
                //$this->connObject->closeDbConnect();
                return false;
            }
        } 
        catch (Exception $e)
        {
            echo $e->getMessage();
        }
    }
    
    //ACID
    //Get the next id  for the PK to put in the FK
    public function getNextID()
    {
        try 
        {
            //Define the query to get the next Id
            $this->dbquery = "SELECT CustomerID
                              FROM customer
                              ORDER BY CustomerID DESC LIMIT 0,1";
            $result = $this->dbObj->query($this->dbquery);
            
            while($row = mysqli_fetch_array($result))
            {
                return $row['CustomerID'] + 1;
            }
            
            
        } catch (Exception $e) 
        {
            echo $e->getMessage();
        }
    }
    
}