<?php
namespace App\Services\Data;


use Carbon\Exceptions\Exception;
use App\Services\Data\Utility\DBConnect;

class OrderDAO
{
    //Define connection string
    private $connObject;
    private $dbname = "activity3";
    private $dbquery;
    private $connection;
    private $dbObj;
    
    //constructor that creates conn with database
    public function __construct($dbObj)
    {
        $this->dbObj = $dbObj;
    }
    //method to add new order
    public function addOrder(string $product, int $customerID)
    {
        try
        {
            
            $this->dbquery =@"INSERT INTO `order`
                             (Product, CustomerID)
                             VALUES
                             ('" . $product . "', " . $customerID . ")";
            
            //$result = mysqli_query($this->conn, $this->dbquery);
            
            if ($this->dbObj->query($this->dbquery))
            {
                //$this->connObject->closeDbConnect();
                return true;
            }
            else
            {
                //$this->connObject->closeDbConnect();
                return false;
            }
        }
        catch (Exception $e)
        {
            echo $e->getMessage();
        }
    }
    
}