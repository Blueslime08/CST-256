<?php
namespace App\Services\Data\Utility;


use mysqli;


class DBConnect
{
    //Define connection string
    private $conn;
    private $servername;
    private $username;
    private $password;
    private $dbname;
    private $dbquery;
    
    //constructor that creates conn with database
    public function __construct(string $dbname)
    {
        //Initialize the properties
        $this->dbname = $dbname;
        $this->servername = "localhost";
        $this->username = "root";
        $this->password = "root";
        
    }
    
    /*
     * create a db connection
     */
    public function getDbConnect()
    {
        //OOP Style
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);
        //create a connection to the database
        //procedural
        //$this->conn = mysqli_connect($this->servername, $this->username, $this->password, $this->dbname);
        
        //$this->conn = mysqli::connect($this->servername, $this->username, $this->password, $this->dbname);
        
        if($this->conn->connect_error)
        {
            echo "failed to connect to MySQL:" . $this->conn->connect_error;
            exit();
        }
        return($this->conn);
    }
    
    /*
     * turn ON Autocommit
     */
    public function setDbAutocommitTrue()
    {
        $this->conn->autocommit(TRUE);
    }
    /*
     * turn OFF Autocommit
     */
    public function setDbAutocommitFalse()
    {
        $this->conn->autocommit(FALSE);
    }
    /*
     * Close the connection
     */
    public function closeDbConnect()
    {
        //Procedural style
        //mysqli_close($this->conn);
        //OOP Style
        $this->conn->close();
    }
    /*
     * Begin a transaction
     */
    public function beginTransaction()
    {
        $this->conn->begin_transaction();
    }
    
    /*
     * Commit a Transaction
     */
    public function commitTransaction()
    {
        $this->conn->commit();
    }
    /*
     * Rollback a transaction
     */
    public function rollbackTransaction()
    {
        $this->conn->rollback();
    }
}