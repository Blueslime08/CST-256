<?php
namespace App\Services\Business;

use App\Models\UserModel;
use App\Models\CustomerModel;
use App\Services\Data\SecurityDAO;
use App\Services\Data\CustomerDAO;
use App\Services\Data\OrderDAO;
use App\Services\Data\Utility\DBConnect;

class SecurityService
{
    private $verifyCred;
    
    public function login(UserModel $credentials)
    {
        $this->verifyCred = new SecurityDAO();
        
        return $this->verifyCred->findByUser($credentials);
    }
    
    //method to manage the customer data in the business layer
    public function addCustomer(CustomerModel $customerData)
    {
        //instantiate the data access layer
        $this->addNewCustomer = new CustomerDAO();
        
        //return true or false by passing customer data
        return $this->addNewCustomer->addCustomer($customerData);
    }
    
    public function addOrder(string $product, int $customerID)
    {
        //instantiate the data access layer
        $this->addNewOrder = new OrderDAO();
        
        //return true or false by passing customer data
        return $this->addNewOrder->addOrder($product, $customerID);
    }
    //manages acid transactions
    public function addAllInformation(string $product, int $CustomerID, CustomerModel $customerData)
    {
        //create a connect to the database
        //create an instance of the class
        $conn = new DBConnect("activity3");
        
        //call the method to create the connection
        $dbObj = $conn->getDbConnect();
        
        //First turn off autocommit
        $conn->setDbAutocommitFalse();
        //Begin transaction
        $conn->beginTransaction();
        
        //instantiate the data access layer
        $this->addNewCustomer = new CustomerDAO($dbObj);
        
        //next customerID
        $customerID = $this->addNewCustomer->getNextID();
        
        //add the customer data
        $isSuccessful = $this->addNewCustomer->addCustomer($customerData);
        
        //instantiate the data access layer
        $this->addNewOrder = new OrderDAO($dbObj);
        //add the product order data
        $isSuccessfulOrder = $this->addNewOrder->addOrder($product, $customerID);
        
        if($isSuccessful && $isSuccessfulOrder)
        {
            $conn->commitTransaction();
            return true;
        }
        else
        {
            $conn->rollbackTransaction();
            return false;
        }
        
        
    }
}