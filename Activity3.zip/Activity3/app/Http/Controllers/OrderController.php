<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CustomerModel;
use App\Services\Business\SecurityService;

class OrderController extends Controller
{
    //To obtain an instance of the current http request from a post
    public function index(Request $request)
    {
        $customerData = new CustomerModel($request->input('firstName'), $request->input('lastName'));
        
        //since we are not using a model
        $product = request()->get('product');
        //this is more efficient way since its not calling a method
        $customerID = $request->input('customerID');
        
        $serviceCustomer = new SecurityService();
        
        $isValid = $serviceCustomer->addAllInformation($product, $customerID, $customerData);
        if($isValid)
        {
            echo("Order Data Committed successfully");
        }
        else 
        {
            echo("Order Data was Rolled Back");
        }
        return view('order');
    }
    //Validation added for activity3
    private function validateForm(Request $request)
    {
        //Setup data validation rules for login form
        $rules = ['user_name'=> 'Required | Between: 4, 10 | Alpha',
                   'password' => 'Required | Between 4, 10'];
        //run the data validation rules
        $this->validate($request, $rules);
    }
}
