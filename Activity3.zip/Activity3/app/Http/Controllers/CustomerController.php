<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CustomerModel;
use App\Services\Business\SecurityService;

class CustomerController extends Controller
{
    //To obtain an instance of the current http request from a post
    public function index(Request $request)
    {
        //create a customermdoel with firstname and lastname
        //$customerData = new CustomerModel($request->get('firstName'), $request->get('lastName'));
        //$serviceCustomer = new SecurityService();
        //$isValid = $serviceCustomer->addCustomer($customerData);
        //if($isValid)
        //{
        //    echo("Customer Data added successfully");
        //}
        //else 
        //{
        //    echo("Customer Data was not added");
        //}
        $nextID = 0;
        return redirect('neworder')->with('nextID', $nextID)
                                   ->with('firstName', request()->get('firstName'))
                                   ->with('lastName', request()->get('lastName'));
        
        
        
//         $formValues = $request->all();
//         $username = $request->get('user_name');
//         return $request->all();
    }
    //Validation added for activity3
    private function validateForm(Request $request)
    {
        //Setup data validation rules for login form
        $rules = ['user_name'=> 'Required | Between: 4, 10 | Alpha',
                   'password' => 'Required | Between 4, 10'];
        //run the data validation rules
        $this->validate($request, $rules);
    }
}
