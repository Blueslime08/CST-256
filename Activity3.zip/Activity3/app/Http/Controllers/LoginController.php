<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Services\Business\SecurityService;

class LoginController extends Controller
{
    //To obtain an instance of the current http request from a post
    public function index(Request $request)
    {
        //added for activity 3
        //Test the form variabls being passed in
        $this->validateForm($request);
        
        $credentials = new UserModel($request->get('user_name'), $request->get('password'));
        $serviceLogin = new SecurityService();
        $isValid = $serviceLogin->login($credentials);
        if($isValid)
        {
            return view('loginPassed2');
        }
        else 
        {
            return view('loginFailed');
        }
        
        
        
//         $formValues = $request->all();
//         $username = $request->get('user_name');
//         return $request->all();
    }
    //Validation added for activity3
    private function validateForm(Request $request)
    {
        //Setup data validation rules for login form
        $rules = ['user_name'=> 'Required | Between: 4, 10 | Alpha',
                   'password' => 'Required | Between 4, 10'];
        //run the data validation rules
        $this->validate($request, $rules);
    }
}
