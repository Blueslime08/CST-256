<html>

<h2>Register Success</h2>
<table>
	<tr>
		<td>Successfully registered as:</td>
		<td><?php echo e($email); ?></td>
	</tr>

	<tr>
		<td><a href="<?php echo e(route('login')); ?>">Login Here</a></td>
	</tr>

</table>

</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\W3T2Authentication2\resources\views/user/register/registerPassed.blade.php ENDPATH**/ ?>