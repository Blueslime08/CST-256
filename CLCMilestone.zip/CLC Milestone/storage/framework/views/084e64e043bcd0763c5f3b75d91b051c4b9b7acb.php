<html>



<?php $__env->startSection('title', 'Login Page'); ?>
<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Login')); ?></div>

                <div class="card-body">
<form action="doLogin" method="POST">
	<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">

	<?php if(isset($error)): ?>
		<div style="color: red">
    		Error: <?php echo e($error); ?> <br>
    		<br>
    	</div>
    <?php endif; ?>	
	<table>
		<tr>
			<td>Email Address:</td>
			<td><input class="form-control"type="text" name="email" /></td>
		</tr>

		<tr>
			<td>Password:</td>
			<td><input class="form-control" type="password" name="password" /></td>
		</tr>

		<tr>
			<br>
			<td colspan="2" align="center"><input type="submit" value="Login" />
			</td>
		</tr>
	</table>
</form>

	Not Registered? <a href="<?php echo e(route('register')); ?>">Create Account Here</a>


<?php $__env->stopSection(); ?>
</div>
</div>
</div>
</div>
</div>
</div>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone\resources\views/user/login/login-form.blade.php ENDPATH**/ ?>