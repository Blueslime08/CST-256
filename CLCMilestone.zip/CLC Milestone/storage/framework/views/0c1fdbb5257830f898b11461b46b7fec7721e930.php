<html>




<?php $__env->startSection('title', 'groups'); ?>
<?php $__env->startSection('content'); ?>


    <div class="my-profile">
    <div class="content-container">
    <div class="job">
    	<h1>Group: <?php echo e($group->getTitle()); ?></h1>
        	<?php if(isset($operation)): ?>
    			<div class="operation">
    				<?php echo e($operation); ?>

    			</div>
    			<br>
    		<?php endif; ?>
    	<table>

    		<tr>
    			<td><b>ID: </b></td> 
    			<td><?php echo e($group->getId()); ?></td> 
    		</tr>
    		<tr>
    			<td><b>Title: </b></td> 
    			<td><?php echo e($group->getTitle()); ?></td> 
    		</tr>
    		<tr>
    			<td><b>Description: </b></td> 
    			<td><textarea readonly><?php echo e($group->getDescription()); ?></textarea></td> 
    		</tr>
    		<tr>
    			<td><b>Creator: </b></td> 
    			<td><?php echo e($creator->getFirstName()); ?> <?php echo e($creator->getLastName()); ?> (
				    <form action="viewProfile" method="GET" style="display: inline;">
                        <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">	
                        <input type="hidden" name ="ID" value="<?php echo e($creator->getId()); ?>">
                        <a href="#" onclick="this.parentNode.submit();"><?php echo e($creator->getEmail()); ?></a>
                                		
                    </form>
				)</td> 
    		</tr>
    		<tr>
    			<td><b>Members (<?php echo e($group->getMembers()); ?>): </b></td> 
    			<td>
    				<?php $__currentLoopData = $group->getUsers(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    				
    					<?php echo e($member->getFirstName()); ?> <?php echo e($member->getLastName()); ?> (
    					<form action="viewProfile" method="GET" style="display: inline;">
                        	<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">	
                            <input type="hidden" name ="ID" value="<?php echo e($member->getId()); ?>">
                            <a href="#" onclick="this.parentNode.submit();"><?php echo e($member->getEmail()); ?></a>
                                		
                       	</form>
    					), 
    				
    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
    			
    			</td> 
    		</tr>
    		<tr>
    			<td><b>Options: </b></td> 
    			<td>
    				<?php if($status == 0): ?> 
                		<form action="joinGroup" method="POST"style="margin: 0; vertical-align: center;">
                			<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                			<input type="hidden" name="ID" value="<?php echo $group->getId() ?>">
                			<input type="submit" value="Join Group" />
                		</form>
            		<?php elseif($status == 1): ?> 
            			<form action="leaveGroup" method="POST"style="margin: 0; vertical-align: center;">
                			<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                			<input type="hidden" name="ID" value="<?php echo $group->getId() ?>">
                			<input type="submit" value="Leave Group" />
                		</form>
            		<?php elseif($status == 2): ?> 
            		    <form action="editGroup" method="POST"style="display: inline; margin: 0; vertical-align: center;">
                			<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                			<input type="hidden" name="ID" value="<?php echo $group->getId() ?>">
                			<input type="submit" value="Edit Group" />
                		</form>
            			<form onSubmit="if(!confirm('Are you sure?')){return false;}" action="deleteGroup" method="POST"style="display: inline; margin: 0; vertical-align: center;">
                			<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                			<input type="hidden" name="ID" value="<?php echo $group->getId() ?>">
                			<input type="submit" value="Delete Group" />
                		</form>
                	<?php endif; ?>
    			
    			</td> 
    		</tr>

    	</table>
    	<a href="<?php echo e(route('groups')); ?>">Back</a>
    		
    	</div>	
    </div>
    </div>
    

<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone\resources\views/user/groups/view-group.blade.php ENDPATH**/ ?>