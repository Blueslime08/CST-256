<?php

namespace App\Models;

class RegisterResponse
{
    //class member variables
    private $success;
    private $msg;
    
    //constructor
    function __construct() {
        $success = false;
    }
    
    //getters and setters
    
    /**
     * @return mixed
     */
    public function getSuccess()
    {
        return $this->success;
    }

    /**
     * @return mixed
     */
    public function getMsg()
    {
        return $this->msg;
    }

    /**
     * @param mixed $success
     */
    public function setSuccess($success)
    {
        $this->success = $success;
    }

    /**
     * @param mixed $data
     */
    public function setMsg($msg)
    {
        $this->msg = $msg;
    }

    
    
    
    
}

