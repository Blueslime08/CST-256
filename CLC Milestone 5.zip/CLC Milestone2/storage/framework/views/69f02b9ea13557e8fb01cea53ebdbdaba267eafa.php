<html>

	<div class="footer">


    		<h5>Copyright @2017  My Own Company Name</h5>

    </div>
</html><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone2\resources\views/layouts/footer.blade.php ENDPATH**/ ?>