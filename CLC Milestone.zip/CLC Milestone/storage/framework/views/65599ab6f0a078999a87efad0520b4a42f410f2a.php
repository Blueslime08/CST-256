<html>



<?php $__env->startSection('title', 'Admin'); ?>




<?php $__env->startSection('content'); ?>


    
    <div class="content-container">
    <div class="admin-panel">
    		<h1>Admin Panel</h1>
    		<div>Select a user below to edit their data</div>
    		<br>
    		<?php if(isset($operation)): ?>
    			<div class="operation">
    				<?php echo e($operation); ?>

    			</div>
    			<br>
    		<?php endif; ?>
    		<form action="adminSearch" method="POST">
    			<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
    			<input type="text" placeholder="Search.." name="search">
    			<input type="submit" value="Search Users" />
    		</form>
    		
    		<table>
    			
    			<th>
    				ID
    			</th>
    			<th>
    				Email Address
    			</th>
    			<th>
    				Password
    			</th>
    			<th>
    				First Name
    			</th>
    			<th>
    				Last Name
    			</th>
    			<th>
    				Rights
    			</th>
    			<th>
    				Role
    			</th>
    			<th>
    				Operation
    			</th>
    			<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				
    			<tr>
    			    <td>	
                    	<?php echo e($user->ID); ?>

                    </td>
        			<td>	
                    	<?php echo e($user->EMAIL); ?>

                    </td>
        			<td>	
                    	<?php echo e($user->PASSWORD); ?>

                    </td>
        			<td>	
                    	<?php echo e($user->FIRSTNAME); ?>

                    </td> 
        			<td>	
                    	<?php echo e($user->LASTNAME); ?>

                    </td>
        			<td>	
                    	<?php echo e($user->RIGHTS); ?>

                    </td>
                    <td>
                        <form action="adminEdit" method="POST" style="display: inline;">
            				<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
            				<input type="hidden" name="ID" value="<?php echo $user->ID ?>">

                        	<input type ="image" src="<?php echo e(asset('public/images/icons/edit.png')); ?>" title="Edit" style="vertical-align:middle; display:inline;" width="24" height="24"> 
                     	</form>
                        <form onSubmit="if(!confirm('Are you sure?')){return false;}" id ="delete" action="adminDelete" method="POST" style="display: inline;">
            				<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
            				<input type="hidden" name="ID" value="<?php echo $user->ID ?>">
                     	    <input type ="image" src="<?php echo e(asset('public/images/icons/delete.png')); ?>" title="Delete" style="vertical-align:middle; display:inline;" width="24" height="24"> 
                     	</form>

                     	
                    </td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </table>
     	</div>
    </div>
    

<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone - Copy\resources\views/user/admin/admin-panel.blade.php ENDPATH**/ ?>