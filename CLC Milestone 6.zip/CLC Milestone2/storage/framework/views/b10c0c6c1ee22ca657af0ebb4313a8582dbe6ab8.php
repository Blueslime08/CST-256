<html>

	<div class="header">

  	<div class="title">
    	<a href="<?php echo e(route('home')); ?>">iNetwork</a>
    </div>


	<div class="top-right">
	
	 	<?php if(session('user')): ?>
			<?php echo $__env->make('navigation.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php else: ?>
			<?php if(\Request::is('home')): ?>  
				<?php echo $__env->make('user.login.login-form-small', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php else: ?>
               <nav>
                    <ul>
                        <li>
                        	<a href="<?php echo e(route('home')); ?>">Home</a>
                        </li>	
                    </ul>
               </nav>
            <?php endif; ?>
		
		<?php endif; ?>
		
		
	</div>

	</div>

</html><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\W3T2Authentication2\resources\views/layouts/header.blade.php ENDPATH**/ ?>