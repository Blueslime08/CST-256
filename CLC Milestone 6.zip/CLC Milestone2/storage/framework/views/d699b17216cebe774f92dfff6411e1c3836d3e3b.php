<html>




<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>

    </div>
    <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Edit Profile')); ?></div>

                <div class="card-body">
                    <form>
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>
                            <div class="col-md-6">
                                <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e($user->getFirstName()); ?></label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>
                            <div class="col-md-6">
                                <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e($user->getPassword()); ?></label>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>
                            <div class="col-md-6">
                                <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e($user->getFirstName()); ?></label>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="gender" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Last Name')); ?></label>
                            <div class="col-md-6">
                                <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e($user->getLastName()); ?></label>
                            </div>
                        </div>
                        
                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\W3T2Authentication2\resources\views/user/profile/my-profile.blade.php ENDPATH**/ ?>