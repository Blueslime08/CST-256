<html>




<?php $__env->startSection('title', 'Job'); ?>
<?php $__env->startSection('content'); ?>


    <div class="my-profile">
    <div class="content-container">
    <div class="job">
    	<h1>View Job: <?php echo e($job->TITLE); ?></h1>
        	<?php if(isset($operation)): ?>
    			<div class="operation">
    				<?php echo e($operation); ?>

    			</div>
    			<br>
    		<?php endif; ?>
    	<table>

    		<tr>
    			<td><b>ID: </b></td> 
    			<td><?php echo e($job->ID); ?></td> 
    		</tr>
    		<tr>
    			<td><b>Title: </b></td> 
    			<td><?php echo e($job->TITLE); ?></td> 
    		</tr>
    		<tr>
    			<td><b>Company: </b></td> 
    			<td><?php echo e($job->COMPANY); ?></td> 
    		</tr>
    		<tr>
    			<td><b>Salary: </b></td> 
    			<td><?php echo e($job->SALARY); ?></td> 
    		</tr>
    		    		
    		<tr>
    			<td><b>Location: </b></td> 
    			<td><?php echo e($job->LOCATION); ?></td> 
    		</tr>
    		<tr>
    			<td><b>Description: </b></td> 
    			<td><textarea readonly><?php echo e($job->DESCRIPTION); ?></textarea></td> 
    		</tr>

    		<tr>
    			<td><b>Experience Required: </b></td> 
    			<td><textarea readonly><?php echo e($job->EXPERIENCE); ?></textarea></td> 
    		</tr>

    		
    		
    	</table>
    	<a href="<?php echo e(route('jobs')); ?>">Back</a>
    		
    	</div>	
    </div>
    </div>
    

<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone - Copy\resources\views/user/jobs/view-job.blade.php ENDPATH**/ ?>