
<html>

<h2>Register Success</h2>
<table>
	<tr>
		<td>Successfully registered as:</td>
		<td>{{ $email }}</td>
	</tr>

	<tr>
		<td><a href="{{route('login')}}">Login Here</a></td>
	</tr>

</table>

</html>