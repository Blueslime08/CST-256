<html>



<?php $__env->startSection('title', 'Jobs'); ?>




<?php $__env->startSection('content'); ?>


    
    <div class="content-container">
    <div class="admin-panel">
    		<h1>Search for Jobs</h1>
    		<br>
    		<?php if(isset($operation)): ?>
    			<div class="operation">
    				<?php echo e($operation); ?>

    			</div>
    			<br>
    		<?php endif; ?>
    		<?php if(isset($errors)): ?>
        		<div style="color: red">
                    <ul style="list-style-type: none">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
            	</div>
            <?php endif; ?>	
    		
    		<form action="doJobSearch" method="POST">
    			<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
    			<input type="text" placeholder="Search.." name="search">
    			<input type="submit" value="Search" />
    		</form>
    		
    		<?php if(isset($jobResults)): ?>
    		<table>
    			
    			<th>
    				ID
    			</th>
    			<th>
    				Title
    			</th>
    			<th>
    				Company
    			</th>
    			<th>
    				Location
    			</th>
    			<th>
    				Operation
    			</th>
    			<?php $__currentLoopData = $jobResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				
    			<tr>
    			    <td>	
                    	<?php echo e($job->getId()); ?>

                    </td>
        			<td>	
                    	<?php echo e($job->getJobTitle()); ?>

                    </td>
        			<td>	
                    	<?php echo e($job->getCompanyName()); ?>

                    </td>
        			<td>	
                    	<?php echo e($job->getLocation()); ?>

                    </td> 
                    <td>

                		<form action="viewJob" method="GET"style="margin: 0; vertical-align: center; display: inline;">
                			<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                			<input type="hidden" name="ID" value="<?php echo $job->getId() ?>">
                			<input type="submit" value="View" />
                		</form>

                    </td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </table>
            
            <?php endif; ?>
     	</div>
    </div>
    

<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone2\resources\views/user/jobs/view-job-search.blade.php ENDPATH**/ ?>