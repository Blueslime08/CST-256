<html>




<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>


    
    
				<div class="content-container">
				<h1>Error: </h1>
				<div class="error"><?php echo e($error); ?></div>
				</div>
		

<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone - Copy\resources\views/error.blade.php ENDPATH**/ ?>