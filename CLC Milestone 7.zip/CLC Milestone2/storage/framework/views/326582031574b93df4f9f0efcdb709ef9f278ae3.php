<html>



<?php $__env->startSection('title', 'Groups'); ?>





<?php $__env->startSection('content'); ?>

    
    
    <div class="content-container">
    <div class="admin-panel">
    		<h1>Affinity Groups</h1>
    		<div><a href="<?php echo e(route('newGroup')); ?>">Create</a> new group</div>
    		<br>
    		<div>Select a group below to view</div>
    	
    		<br>
    		<?php if(isset($operation)): ?>
    			<div class="operation">
    				<?php echo e($operation); ?>

    			</div>
    			<br>
    		<?php endif; ?>

    		
    		<table>
    			
    			<th>
    				ID
    			</th>
    			<th>
    				Title
    			</th>
    			<th>
    				Operation
    			</th>

    			<?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				
    			<tr>
    			    <td>	
                    	<?php echo e($group->getId()); ?>

                    </td>
        			<td>	
                    	<?php echo e($group->getTitle()); ?>

                    </td>
                    <td>


                		<form action="viewGroup" method="GET"style="margin: 0; vertical-align: center; display: inline;">
                			<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                			<input type="hidden" name="ID" value="<?php echo $group->getId() ?>">
                			<input type="submit" value="View" />
                		</form>
                		<?php if(session('user')->getRights() > 0): ?> 
                			<form action="editGroup" method="POST"style="margin: 0; vertical-align: center; display: inline;">
                    			<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                    			<input type="hidden" name="ID" value="<?php echo $group->getId() ?>">
                    			<input type="submit" value="Edit" />
                    		</form>
                			<form onSubmit="if(!confirm('Are you sure?')){return false;}" action="deleteGroup" method="POST"style="display: inline; margin: 0; vertical-align: center;">
                    			<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                    			<input type="hidden" name="ID" value="<?php echo $group->getId() ?>">
                    			<input type="submit" value="Delete" />
                    		</form>
                    	<?php endif; ?>
						


                     	
                    </td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </table>
     	</div>
    </div>
    

<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone2\resources\views/user/groups/view-groups.blade.php ENDPATH**/ ?>