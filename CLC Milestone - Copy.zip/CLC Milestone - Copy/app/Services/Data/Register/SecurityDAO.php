<?php
namespace App\Services\Data\Register;

use Illuminate\Support\Facades\DB;

class SecurityDAO
{
    

    
    //function that checks if user with email exists
    public function findEmail($registerRequest) {
        $response = DB::table('users')->where('EMAIL', $registerRequest->getEmail())->count();
        
        if ($response > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    //function that inserts new user in database
    public function createUser($registerRequest) {
        $result = DB::table('users')->insert(
            ['EMAIL' => $registerRequest->getEmail(), 
                'PASSWORD' => $registerRequest->getPassword(), 
                'FIRSTNAME' => $registerRequest->getFirstName(), 
                'LASTNAME' => $registerRequest->getLastName(),
            ]);
        
        return $result;

    }
    
    
}

