<html>



<?php $__env->startSection('title', 'Jobs'); ?>




<?php $__env->startSection('content'); ?>


    
    <div class="content-container">
    <div class="admin-panel">
    		<h1>Job Listings</h1>
    		<?php if(session('user')->getRights() > 0): ?> 
    			<div>Admin permissions: <a href="<?php echo e(route('newJob')); ?>">Create</a> new job listing</div>
    		<?php endif; ?>
    		<br>
    		<div>Select a job below to view</div>
    	
    		<br>
    		<?php if(isset($operation)): ?>
    			<div class="operation">
    				<?php echo e($operation); ?>

    			</div>
    			<br>
    		<?php endif; ?>

    		
    		<table>
    			
    			<th>
    				ID
    			</th>
    			<th>
    				Title
    			</th>
    			<th>
    				Company
    			</th>
    			<th>
    				Location
    			</th>
    			<th>
    				Operation
    			</th>
    			<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				
    			<tr>
    			    <td>	
                    	<?php echo e($job->ID); ?>

                    </td>
        			<td>	
                    	<?php echo e($job->TITLE); ?>

                    </td>
        			<td>	
                    	<?php echo e($job->COMPANY); ?>

                    </td>
        			<td>	
                    	<?php echo e($job->LOCATION); ?>

                    </td> 
                    <td>
                    	<a href="<?php echo e(route('viewJob', ['id'=>$job->ID])); ?>">View</a>
                    	<?php if(session('user')->getRights() > 0): ?> 
                            <a href="<?php echo e(route('editJob', ['id'=>$job->ID])); ?>">Edit</a>
                            <a href="<?php echo e(route('deleteJob', ['id'=>$job->ID])); ?>">Delete</a>
                     	<?php endif; ?>

                     	
                    </td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </table>
     	</div>
    </div>
    

<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone - Copy\resources\views/user/jobs/view-jobs.blade.php ENDPATH**/ ?>