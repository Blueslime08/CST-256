<?php echo "Login Passed!" . "\n" . "User: " . $user->getUsername() . " "; ?>
