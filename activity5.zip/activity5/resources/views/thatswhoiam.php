<h2> Hello!</h2>
	<?php echo $firstName . " " . $lastName; ?>
	<br>
	<a href="askme">Go Again</a>
